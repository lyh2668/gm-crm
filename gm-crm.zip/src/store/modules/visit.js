const state = {
  visitList: []
}

const getters = {

}

const mutations = {

}

const actions = {

}

const visit = {
  state,
  getters,
  actions,
  mutations
}

export default visit
