// import module1 from './module1'
// import module2 from './module2'
import business from './business'
import customer from './customer'
import visit from './visit'

export default {
  // module1,
  // module2,
  business,
  customer,
  visit
}
