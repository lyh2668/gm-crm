const state = {
  customerList: []
}

const getters = {

}

const mutations = {

}

const actions = {

}

const customer = {
  state,
  getters,
  actions,
  mutations
}

export default customer
