export default {
  ERR_OK: 0 // ERR_OK 表示成功
}
